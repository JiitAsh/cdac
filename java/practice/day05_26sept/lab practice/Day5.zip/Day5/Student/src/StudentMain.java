package com.cdac.acts;
import com.cdac.acts.Student;
public class StudentMain
{
	public static void main(String ...args)
	{
		Student s1=new Student("abcd", 123);
		System.out.println(s1.toString());
	}
}