package com.cdac.acts;
import com.cdac.acts.Item;
import java.util.Scanner;
public class ItemMain{
	public static void main(String ...args){
	   Scanner sc = new Scanner(System.in);
	   Item[] itemStock = new Item[10];
	   
	   do{
	   }
	   
	   
	   /*
	   Item item1 = new Item("apple", 125.25, 10);
	   Item item2 = new Item();

	   System.out.println("Enter the name: ");
	   String name=sc.nextLine();
	   System.out.println("Enter the price: ");
	   double price=sc.nextDouble();
	
	   System.out.println("Enter the quantity: ");
	   int quantity = sc.nextInt();
	   sc.nextLine();
	   item2.get(name,price,quantity);
	   
	   
	   System.out.println(item1.toString());
	   System.out.println(item2.toString());
	   */
	   
	   
	   
	   
	   
	   sc.close();
	   
	}
}