
public enum Enum{
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	THURSDAY,
	FRIDAY, 
	SATURDAY,
}




/*
public enum Enum{
	SE("Software Eng"),
	HR("HR Exe"),
	MD("Managing Director");
	
	private String str1;
	private Enum(String str){
		this.str1 = str;
	}
	
	
	
	public String getVal(){
		return str1;
	}
}
*/