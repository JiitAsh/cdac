package com.cdac;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;
public class Tester {
	
	public static List<Fruit> addFruits() {
		Fruit f1=new Fruit("Banana", "yellow", 50, 12);
		Fruit f2=new Fruit("Custard Apple", "green", 120, 15);
		Fruit f3=new Fruit("Orange", "orange", 200, 10);
		Fruit f4=new Fruit("Apple", "red", 150, 6);
		List<Fruit> list=new ArrayList<>();
		list.add(f1);
		list.add(f2);
		list.add(f3);
		list.add(f4);
		return list;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		List<Fruit> fruitList = addFruits();
		



		
		// advanced for loop
		for(Fruit f : fruitList){
//		System.out.println(f.toString());   
        System.out.println(f);  // both will give same output
		}
		
		Collections.sort(fruitList, new colorComparator());
		
		
		sc.close();
	}

}
