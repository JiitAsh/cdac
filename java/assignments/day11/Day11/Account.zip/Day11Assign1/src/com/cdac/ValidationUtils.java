package com.cdac;

import java.time.LocalDate;

public class ValidationUtils {
	public static LocalDate validate(String date) {
		LocalDate today=LocalDate.now();
		LocalDate ld=LocalDate.parse(date);
		if (ld.isBefore(today) || ld.isEqual(today)){
			return ld;
		}
		return null;
	}
}
