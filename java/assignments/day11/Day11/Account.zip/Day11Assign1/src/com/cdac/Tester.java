package com.cdac;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import com.cdac.ValidationUtils;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		List<Account> accList = DataEntry.entry();
		
		/*		int choice=0;		System.out.print("Enter the acc no.: ");		Integer accNo = sc.nextInt();		sc.nextLine();		System.out.print("BEnter the name: ");		String accName = sc.nextLine();		System.out.print("Enter valid date(yyyy-MM-dd): ");		String date = sc.nextLine();		LocalDate openingDate=ValidationUtils.validate(date);		if(null==date) {			System.out.println("Invalid date");		}		else {		System.out.print("Enter balance to deposit ");		Double balance=sc.nextDouble();		accList.add(new Account(accNo, accName, openingDate, balance));		}
				System.out.println(accList);
 */
		
		for(Account ac: accList) {
			System.out.println(ac);
		}
		System.out.println();
		System.out.println();
		Collections.sort(accList, new accNoComparator());
		Collections.sort(accList, new accNameComparator());
		Collections.sort(accList, new accDateofOpeningComparator());
		Collections.sort(accList, new BalanceComparator());
		System.out.println("After sorting the list: ");
		for(Account ac: accList) {
			System.out.println(ac);
		}
		sc.close();
	}

}
