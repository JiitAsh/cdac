package com.cdac;

import java.time.LocalDate;

public class Account  {
	private Integer accNo;
	private String accName;
	private LocalDate dateOfOpening;
	private Double balance;
	
	public Account() {
		accNo = 0;
		accName = "";
		dateOfOpening  = LocalDate.now();
		balance = 0.0;
	}

	public Integer getAccNo() {
		return accNo;
	}

	public String getAccName() {
		return accName;
	}

	public LocalDate getDateOfOpening() {
		return dateOfOpening;
	}

	public Double getBalance() {
		return balance;
	}

	public Account(Integer accNo, String accName, LocalDate dateOfOpening, Double balance) {
		super();
		this.accNo = accNo;
		this.accName = accName;
		this.dateOfOpening = dateOfOpening;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", accName=" + accName + ", dateOfOpening=" + dateOfOpening + ", balance="
				+ balance + "]";
	}
	
//	@Override
//	public int compareTo(Account ac) {
//		return this.accNo.compareTo(ac.accNo);
//	}
	
}
