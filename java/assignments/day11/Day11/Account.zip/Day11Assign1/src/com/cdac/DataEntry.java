package com.cdac;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DataEntry {
	public static List<Account> entry(){
	List <Account> ls=new ArrayList<>();
	String name1="Jitesh";
	String name2="Atharv";
	String name3="Zyan";
	LocalDate date1=ValidationUtils.validate("2023-11-12");
	LocalDate date2=ValidationUtils.validate("2023-10-12");
	LocalDate date3=ValidationUtils.validate("2018-03-22");
	Double balance1=1000.23;
	Double balance2=10.00;
	Double balance3=976346.78;
		ls.add(new Account(90009, name1, date1, balance1));
		ls.add(new Account(1874, name2, date2, balance2));
		ls.add(new Account(8434, name3, date3, balance3));
	return ls;
	}
}
