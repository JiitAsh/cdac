package com.cdac.shape;

abstract public class Shape {
	
	public Shape(){
		
	}
	abstract public double calculateArea();
	abstract public double calculatePerimeter();

}
