package com.cdac.interfaceexample.Exception;

public class ArrayIndexFull extends Exception{
	public ArrayIndexFull(String msg) {
		super(msg);
	}
}
