package com.cdac.shape.drawable;

public interface Drawable {
	void draw();
}
