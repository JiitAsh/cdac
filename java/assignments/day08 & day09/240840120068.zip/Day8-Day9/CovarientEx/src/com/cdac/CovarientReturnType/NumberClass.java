package com.cdac.CovarientReturnType;

abstract public class NumberClass {
	
	abstract public Number addNumber(Number a, Number b);
}
