package com.cdac.acts.Account.exception;

public class MinBalnceException extends Exception {

	public MinBalnceException(String msg) {
		super(msg);
	}

}
