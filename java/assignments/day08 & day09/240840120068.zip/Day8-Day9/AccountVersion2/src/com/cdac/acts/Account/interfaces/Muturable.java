package com.cdac.acts.Account.interfaces;

public interface Muturable {
	
	double calculateMatutyAmount( int time);
}
