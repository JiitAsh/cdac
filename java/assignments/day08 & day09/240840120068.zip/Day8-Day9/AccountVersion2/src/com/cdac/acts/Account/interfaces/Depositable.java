package com.cdac.acts.Account.interfaces;


public interface Depositable {
		 double deposite( double amount);
}

