#include<iostream>
using namespace std;

int main(){
int p,t;
float r;
cout<<"Enter p,r and t: ";
cin>>p>>r>>t;
double simpleInterest =(p*r*t)/100;
cout<<simpleInterest<<endl;
return 0;
}
