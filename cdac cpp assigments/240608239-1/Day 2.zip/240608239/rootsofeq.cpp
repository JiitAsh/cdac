#include<iostream>
#include<cmath>
using namespace std;

int main(){

int a,b,c;
cout<<"Enter a,b and c : ";
cin>>a>>b>>c;
if(a==0) cout<<"Invalid equation"<<endl;

int d=b*b - 4*a*c;
if(d<0){  
cout<<"Roots are not real"<<endl;

}
else if(d==0){ 
cout<<"Both roots are same and have value equal to: ";
double root = - (double)b / 2*a;
cout<<root<<endl;
}
else{
d=sqrt(d);
double root1=( -(double)b - double(d) )/2*a;
double root2 = (-(double)b + double(d))/(2*a);
cout<<"Roots are : "<<root1<<" and " <<root2<<endl;
}

return 0;
}
