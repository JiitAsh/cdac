#include<iostream>
#include<string>
using namespace std;
int main(){
 int n;
cin>>n;
char ch[n];
string str="";
for(int i=0; i<n; i++){
  cout<<"\nEnter the character: ";
  cin>>ch[i];
str+=ch[i];
}
cout<<"\nThe string is: ";
cout<<str<<endl;
return 0;
}
