#include<iostream>
#include<bits/stdc++.h>
using namespace std;


struct Student{
  int rNo;
  string name;
}; 

void input(Student* s, int n){
 for(int i=0; i<n; i++){
   cout<<"Enter the name of the student-"<<(i+1)<<": ";
   cin>>s[i].name;
   cout<<"\nEnter the roll no of student-"<<(i+1)<<": ";
   cin>>s[i].rNo; 
 }
return;
}
void display(Student *s, int n){
  for(int i=0; i<n; i++){
  cout<<"Student-"<<(i+1)<<": "<<endl;
  cout<<" name: "<<s[i].name<<"; roll no.:  "<<s[i].rNo<<endl;
  cout<<endl<<endl;
  }
 return; 
}
int main(){
 int n;
 cout<<"Enter the no of students: ";
 cin>>n;
 Student s[n];
 input(s, n);
 display(s, n);
return 0;
}
