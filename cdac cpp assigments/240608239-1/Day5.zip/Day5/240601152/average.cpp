#include<iostream>
using namespace std;
void findAverage(int n){
  int* arr=new int[n];
  int sum=0;
  for(int i=0; i<n; i++){
   cout<<"Enter the number: ";
   cin>>arr[i];
  }
  for(int i=0; i<n; i++){
    sum+=arr[i];
  }
  cout<<"The average is: "<<(float)sum/n;
}
int main(){
int n;
cin>>n;
findAverage(n);
return 0;
}
