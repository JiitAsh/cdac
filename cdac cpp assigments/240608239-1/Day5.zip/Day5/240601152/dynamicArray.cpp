#include<iostream>
using namespace std;

void sortFunc(int* arr, int n){
   for(int i=0; i<n-1; i++)
   {
 	for(int j=i+1; j<n; j++)
        {
            if(arr[i]>arr[j]) swap(arr[i], arr[j]);
        }	
   }
}

int main()
{
int n;
cout<<"\nEnter the no. of array elements: ";
cin>>n;
int* const arr=new int[n];
for(int i=0; i<n; i++)
{
  cout<<"Enter the element: ";
  cin>>arr[i];
}
sortFunc(arr, n);
cout<<"The sorted array is: ";
for(int i=0; i<n; i++)
{
  cout<<arr[i]<<" "; 
}
return 0;
}
