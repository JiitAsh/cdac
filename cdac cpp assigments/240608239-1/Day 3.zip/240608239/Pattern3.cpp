#include<iostream>
using namespace std;
int main()
{
int n;
cin>>n;
for(int i=1; i<=n; i++)
{
for(int spaces=1; spaces<=i-1; spaces++) cout<<" ";
for(int j=i; j<=n; j++) cout<<"*";
cout<<endl;
}
return 0;
}
