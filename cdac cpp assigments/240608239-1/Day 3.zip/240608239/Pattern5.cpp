#include<bits/stdc++.h>
using namespace std;

int main(){
int n;
cout<<"Enter a number: ";
cin>>n;
int totalLine=2*n + 1;
int refNum=n+1;
for(int i=1;i<=totalLine;i++){
 for(int j=1;j<=totalLine;j++){
  int dis=abs(refNum-i)+abs(refNum-j);
  if(dis<refNum && dis%2==1) cout<<"*";
  else cout<<" ";
 }
 cout<<endl;
}
cout<<endl;
return 0;
}
