#include<iostream>
using namespace std;
int main(){
int n;
cin>>n;
for(int i=0, oddNo=1; i<n, oddNo<50;i++,oddNo+=2){
cout<<oddNo<<endl;
}
return 0;
}
