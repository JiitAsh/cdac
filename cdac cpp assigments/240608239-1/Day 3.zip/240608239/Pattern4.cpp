#include<bits/stdc++.h>
using namespace std;

int main(){
int n;
cin>>n;

int maxLine=2*n+1;
int halfSpaces=(maxLine-2)/2;
int refNum=n+1;

for(int i=1;i<=maxLine;i++){
	for(int j=1;j<=maxLine;j++){
		if((abs(refNum-j) + abs(refNum-i))<=halfSpaces) cout<<" ";
		else cout<<"*";
	}
	 cout<<endl;

}
cout<<endl;
return 0;
}
