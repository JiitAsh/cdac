package ticket.entity;

public enum Category {
	    SIM,
	    CALLING,
	    BROADBAND;
}
