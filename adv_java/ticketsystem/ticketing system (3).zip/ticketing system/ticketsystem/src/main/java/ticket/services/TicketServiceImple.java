package ticket.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ticket.dto.TicketsDTO;
import ticket.entity.Tickets;
import ticket.repo.Repository;

@Service
public class TicketServiceImple implements TicketService {

	@Autowired
	Repository repo;

	@Override
	public boolean createTicket(TicketsDTO dto) {
		dto.setStatus("open");
		dto.setCreationDate(new Date());
		Tickets ticketObj = new Tickets();
		BeanUtils.copyProperties(dto, ticketObj);
		repo.save(ticketObj);
		return true;
	}

	@Override
	public boolean updateTicket(TicketsDTO dto) {
		int ticketId = dto.getTicketId();
		TicketsDTO ticketToUpdate = getTicketById(ticketId);
		dto.setStatus("progress");
		dto.setCreationDate(ticketToUpdate.getCreationDate());
		Tickets ticketObj = new Tickets();
		BeanUtils.copyProperties(dto, ticketObj);
		repo.save(ticketObj);
		return true;
	}

	@Override
	public TicketsDTO getTicketById(int ticketId) {
		Optional<Tickets> optTicket = repo.findById(ticketId);
		
		if(optTicket.isPresent()) {
			Tickets eTicket = optTicket.get();
			TicketsDTO dto = new TicketsDTO();
			BeanUtils.copyProperties(eTicket, dto);
			return dto;
		}
		return null;
	}

	@Override
	public List<TicketsDTO> getOpenTickets() {
		Iterator<Tickets> iter = repo.findAll().iterator();
		ArrayList<TicketsDTO> finalList = new ArrayList<>();
		
		while(iter.hasNext()) {
			Tickets eTicket = iter.next();
			if(eTicket.getStatus() !=null && eTicket.getStatus().equals("open")) {
				TicketsDTO dto = new TicketsDTO();
				BeanUtils.copyProperties(eTicket, dto);
				finalList.add(dto);
			}
		}
		return finalList;
	}

	@Override
	public boolean closeTicket(TicketsDTO dto) {
		int ticketId = dto.getTicketId();
		TicketsDTO ticketToClose = getTicketById(ticketId);
		dto.setCreationDate(ticketToClose.getCreationDate());
		dto.setStatus("close");
		dto.setResDate(new Date());
		Tickets ticketObj=new Tickets();
		BeanUtils.copyProperties(dto, ticketObj);
		repo.save(ticketObj);
		return true;
	}

}
