package ticket.services;

import java.util.List;

import ticket.dto.TicketsDTO;

public interface TicketService {
	public boolean createTicket(TicketsDTO dto);
	public boolean updateTicket(TicketsDTO dto);
	public TicketsDTO getTicketById(int ticketId);
	public List<TicketsDTO> getOpenTickets();
	public boolean closeTicket(TicketsDTO dto);
}
