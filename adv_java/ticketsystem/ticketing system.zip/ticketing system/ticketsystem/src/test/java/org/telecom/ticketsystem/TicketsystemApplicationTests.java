package org.telecom.ticketsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
