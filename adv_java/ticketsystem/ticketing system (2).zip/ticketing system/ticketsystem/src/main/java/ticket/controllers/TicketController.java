package ticket.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ticket.dto.TicketsDTO;
import ticket.services.TicketService;

@RestController
@RequestMapping("/ticket")
public class TicketController {
	
	@Autowired
	TicketService tService;
	
	@PostMapping("/addTicket")
	public boolean addTicket(@RequestBody TicketsDTO dto) {
		return tService.createTicket(dto);
	}
	
	@GetMapping("/getTicket/{tid}")
	public TicketsDTO getTicketById(@PathVariable("tid") int ticketId) {
		return tService.getTicketById(ticketId);
	}
	
	@PutMapping("/updateTicket")
	public boolean updateTicket(@RequestBody TicketsDTO dto) {
		return tService.updateTicket(dto);
	}
	
	@GetMapping("/getOpenTickets")
	public List<TicketsDTO> getAllOpenTickets() {
		return tService.getOpenTickets();
	}
}
