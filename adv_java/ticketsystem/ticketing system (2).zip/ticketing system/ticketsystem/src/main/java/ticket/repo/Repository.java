package ticket.repo;

import org.springframework.data.repository.CrudRepository;

import ticket.entity.Tickets;

public interface Repository extends CrudRepository<Tickets, Integer> {
	
}
