package com.cdac.springboothiberapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringboothiberappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringboothiberappApplication.class, args);
	}

}
