package com.doublylinkedlist;

public interface DLListMethods {
	void addAtRear(int element);
	int deleteFirstNode();
	void print();
	boolean isEmpty();
}
