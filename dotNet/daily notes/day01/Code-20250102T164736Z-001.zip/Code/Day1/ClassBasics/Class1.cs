﻿//using Payroll.n1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassBasics
{
    internal class Class2
    {
        //Class1
    }
}
